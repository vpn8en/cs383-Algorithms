package carcassonne;

//import static org.junit.Assert.*;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.introcs.StdDraw;


public class TestCarcassonne {
	Queue<Player> testQueue;
	Queue<Tile> testTiles;

	Double [] data;
	@Before
	public void setUp() throws Exception {
		testQueue = new Queue<Player>();
		Player player0 = new Player("Bob","Blue");
		Player player1 = new Player("Bill","Red");
		Player player2 = new Player("Frank","Black");
		Player player3 = new Player("Amy","Green");

		testQueue.enqueue(player0);
		testQueue.enqueue(player1);
		testQueue.enqueue(player2);
		testQueue.enqueue(player3);

		testTiles = new <Tile>Queue();
		Tile.initTiles(testTiles);
	}
	
	
	
	@Test
	public void testPlayer(){
		new Player("Ben", "Blue");
	}

	@Test
	public void testQueue(){
		assertEquals("Bob", testQueue.dequeue().name);
		assertEquals("Bill", testQueue.dequeue().name);
		assertEquals("Frank", testQueue.dequeue().name);
		assertEquals("Amy", testQueue.dequeue().name);	
	
	}

	@Test
	public void testTiles(){
		for (int i = 0; i < testTiles.size(); i++) {
			assertEquals(false, testTiles.dequeue().hasMeeple());
			//assertEquals("Tiles/"+"0tile00.jpg",testTiles[i].getImageFile());//Primitive testing
		}
	}
	
	@Test
	public void testGUI(){
		new CarcassonneGUI(testQueue,testTiles);
		//StdDraw.show(10000);
		}
}