package carcassonne;

import java.awt.Color;

public class Meeple {

	private String color;
	private String imageFile;
	private String smallImageFile; //imagefile for meeples on the board
	private boolean onBoard = false;
	
	public Meeple(String color){
		this.color = color;
		this.imageFile = "Meeple/"+color+"Meeple.png";
		this.smallImageFile = "Meeple/"+color+"SmallMeeple.png";
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public Boolean getOnBoard(){
		return onBoard;
	}
	
	public void setOnBoard(Boolean b){
		this.onBoard = b;
	}
	
	public String getImageFile(){
		return imageFile;
	}
	public String getSmallImageFile(){
		return smallImageFile;
	}
	
}
