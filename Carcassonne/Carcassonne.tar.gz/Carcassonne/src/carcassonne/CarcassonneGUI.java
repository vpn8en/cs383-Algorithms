package carcassonne;

import java.awt.Color;

import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.introcs.StdDraw;


public class CarcassonneGUI{

	public static final int BORDER = 26;
	public static final int GAP = 52;	
    public static final int BOARD_WIDTH = ((BORDER*2))*11;
    public static final int BOARD_HEIGHT = ((BORDER*2))*10;
    public static final int WIDTH = BOARD_WIDTH + 300;
    public static final int HEIGHT = BOARD_HEIGHT + 50;
    public int printY;
	public int printX = 700 + BORDER;
    private Queue<Tile> playedTiles = new <Tile>Queue();


    public CarcassonneGUI(Queue<Player> playerQueue, Queue<Tile> tiles) {
    	StdDraw.setCanvasSize(WIDTH,HEIGHT);
    	StdDraw.setYscale(0,HEIGHT);
    	StdDraw.setXscale(0,WIDTH);
    	paintBoard(playerQueue);
    	showMeeple(playerQueue);
    	showPlayers(playerQueue);
    	run(playerQueue, tiles);
//    	showTiles(tiles);
    }


    private void run(Queue<Player> playerQueue, Queue<Tile> tiles) {
		// TODO Auto-generated method stub
    	Tile t = tiles.dequeue();
    	placeFirstTile(t);
    	while(!tiles.isEmpty()){
    		for(Player p: playerQueue){
   			StdDraw.setPenColor(Color.BLACK);
   			StdDraw.text(750, 100, "" + tiles.size());
    		StdDraw.text(printX,printY,p.name + "! It is your Turn!");
    		printY -= BORDER;
    		StdDraw.text(printX,printY,"Click board to place tile");
    		printY -= BORDER;
    		StdDraw.text(printX,printY,"displayed below");
    		printY -= BORDER;
    		t = tiles.dequeue();
    		placeTile(t,p);
    		clearDialogue();
    		showMeeple(playerQueue);
    		showPlayers(playerQueue);
    		}
    	}
		System.exit(0);
	}


	private void clearDialogue() {
		// TODO Auto-generated method stub
		StdDraw.setPenColor(Color.WHITE);
		StdDraw.filledRectangle(750,150,150,200);
	}


	private void showPlayers(Queue<Player> playerQueue) {
		int i = BORDER;
    	for (Player p : playerQueue) {
    		StdDraw.setPenColor(Color.WHITE);
    		StdDraw.filledRectangle(3*BORDER + BOARD_WIDTH, HEIGHT - i, 50, 20);
    		StdDraw.setPenColor(Color.BLACK);
    		StdDraw.text(3*BORDER + BOARD_WIDTH, HEIGHT-i, p.name + ": " + p.score);
    		i+= 2*BORDER;
    	}	printY = HEIGHT - i;
	}
	
	private void showMeeple(Queue<Player> playerQueue) {//shows each player's array of meeple

		StdDraw.setPenColor(Color.WHITE);
		StdDraw.filledRectangle(750, 475, 50, 100);//cover meeple
    	int offset = BORDER;
    	int horizontalSpacing;
    	for(Player p : playerQueue){
    		horizontalSpacing = 70;
    		for(int i = 0; i < p.meeples.length; i++){
    			if(!p.meeples[i].getOnBoard()){
    	    		StdDraw.picture((5*BORDER + BOARD_WIDTH) + horizontalSpacing , HEIGHT-(offset), p.meeples[i].getImageFile());
    	    		horizontalSpacing -= 10;
    			}else{
    				//get meeple location and draw on board
    				
    			}
    		}
    		offset += 2*BORDER;
    	}
	}


	private void placeTile(Tile t, Player p) {
		// TODO Auto-generated method stub
		StdDraw.picture(700, 100, t.getImageFile()[0]);
		double x = 0,y = 0;
		while((x < BORDER) || (x > BORDER + BOARD_WIDTH)||(y < BORDER) || (y > BORDER + BOARD_HEIGHT)){
			while(!StdDraw.mousePressed()){
			}
			x = StdDraw.mouseX();
			//System.out.println(x);
			y = StdDraw.mouseY();
			//System.out.println(y);
			if((x < BORDER) || (x > BORDER + BOARD_WIDTH)||(y < BORDER) || (y > BORDER + BOARD_HEIGHT)){
				System.err.println("Please click onto the board to place your tile");
			}
		}
		if(x - x%BORDER == x - x%GAP){
			x = x - x%BORDER;
		}else{
			x = (x - x%BORDER) + BORDER ;
		}
		if(y - y%BORDER ==  y - y%GAP){
			y = y - y%BORDER;
		}else{
			y = (y - y%BORDER) + BORDER ;
		}

		t.setxLocation((int)x);
		t.setyLocation((int)y);
		
		int index = 0;
    	StdDraw.picture(t.getxLocation(), t.getyLocation(), t.getImageFile()[index]);//the index determines the rotation
    	StdDraw.setPenColor(Color.WHITE);//cover the image of the upcoming tile to avoid confusion
    	StdDraw.filledSquare(700, 100, 75);

    	StdDraw.setPenColor(Color.BLACK);//Write instructions to player
    	StdDraw.text(printX, printY, "Press Enter to Place Tile");
    	printY -= 20;
    	StdDraw.text(printX, printY, "Press '.' to rotate Right");
    	printY -= 20;
    	StdDraw.text(printX, printY, "Press ',' to rotate Left ");
    	printY -= 20;
    	StdDraw.text(printX, printY, "Press 'n' to relocate Tile");
    	printY-=20;
    	
    	char c = ' ';
    	char ch = ' ';
    	while(c != '\n'){
    	while(!StdDraw.hasNextKeyTyped()){
    	}
    	c = StdDraw.nextKeyTyped();
    	if(c == '.'){
    		System.out.println("Rotating Tile Right");
    		index = (index + 1) % 4;
        	StdDraw.picture(t.getxLocation(), t.getyLocation(), t.getImageFile()[index]);//the index determines the rotation
    	}
    	else if(c == ','){
    		System.out.println("Rotating Tile Left");
    		if(index > 0){
    			index--;
    		}else index = 3;
        	StdDraw.picture(t.getxLocation(), t.getyLocation(), t.getImageFile()[index]);//the index determines the rotation
    	}else if(c == 'n'){//there is a bug when replacing tiles
    		System.out.println("Replaceing Tile");
    		StdDraw.text(printX, printY, "Replacing Tile");
    		printY -= 20;
    		StdDraw.setPenColor(Color.WHITE);
        	StdDraw.filledSquare(t.getxLocation(), t.getyLocation(), 27);
    		placeTile(t,p);
    	}else if(c =='\n'){
    		t.setBeenPlayed(true);
    		playedTiles.enqueue(t);
    		StdDraw.text(printX, printY, "Tile has been placed");
    		printY -=20;
    		StdDraw.text(printX+BORDER, printY, "Would you like to place a follower?");
    		printY -=20;
    		System.out.println("Tile has been played, would you like to place a follower?(y/n)");
//    		System.out.println("Tile has been played, would you like to place a follower? Press 1 to place in Castle, 2 to place on Road, 3 to place on Cloister.");
    		while(!StdDraw.hasNextKeyTyped()){
        	}
    		ch = StdDraw.nextKeyTyped();
    		if(ch == 'y'){
    			int i = p.getNextFollower();
    			if(i != -1){
    	        	StdDraw.picture(t.getxLocation(), t.getyLocation(), p.meeples[i].getSmallImageFile());
    	        	StdDraw.text(printX+ BORDER, printY, p.name+" Has placed a follower");
    	        	printY -= 20;
    	        	System.out.println(p.name + " Has placed a follower.");
    			}else System.out.println("You have no available followers to place.");
    		}
    		else System.out.println("No Meeple has been placed");
    		System.out.println(p.name + " your turn is through");
    	}
    	else{
    		System.out.println(c + " is not a valid entry, Listening for new command. Press Enter if satisfied with placement.");	
    	}
    	}
	}


	private void placeFirstTile(Tile t) {
		t.setxLocation(6*GAP);
		t.setyLocation(6*GAP);
    	StdDraw.picture(t.getxLocation(), t.getyLocation(), t.getImageFile()[0]);		
    	t.setBeenPlayed(true);
    	playedTiles.enqueue(t);
	}


	private void paintBoard(Queue<Player> playerQueue) {
    	StdDraw.text((2*BORDER + BOARD_WIDTH)/2, HEIGHT-(BORDER/2), "Carcassone");

    	StdDraw.setPenRadius(.007);
    	StdDraw.line(BORDER,BORDER,BORDER,BORDER+BOARD_HEIGHT);//verticle Boundary, Left
    	StdDraw.line(BOARD_WIDTH+BORDER,BORDER,BOARD_WIDTH+BORDER,BOARD_HEIGHT+BORDER);//verticle boundary, Right
    	StdDraw.line(BORDER,BORDER+BOARD_HEIGHT,BOARD_WIDTH+BORDER,BOARD_HEIGHT+BORDER);//Horizontal boundary top
    	StdDraw.line(BORDER,BORDER,BOARD_WIDTH+BORDER,BORDER);//horizontal boundary bottom
    	StdDraw.setPenRadius(.002);
    	for (int j = BORDER; j < BOARD_WIDTH+BORDER ; j+=GAP) {
			StdDraw.line(j,BORDER+BOARD_HEIGHT,j,BORDER);
			StdDraw.line(BORDER+BOARD_WIDTH,j,BORDER,j);
		}
	}
    
    private void showTiles(Queue<Tile> played){//THIS METHOD IS CURRENTLY BEING FIXED
    	int counter = 0;
    	int i = BORDER;
    	int j = BORDER*2;
    	for(Tile t : played){
    		StdDraw.picture(t.getxLocation(), t.getyLocation(), t.getImageFile()[0]);
    		i+=52;
    		counter++;
    		if (counter == 11){
    			i = BORDER;
    			j+= 52;
    			counter = 0;
    		}
    	}
    }
}
