package carcassonne;

import java.util.Random;

import edu.princeton.cs.algs4.Queue;

public class Tile {
	
	private String[] imageString;
	private boolean hasMeeple = false;
	private boolean beenPlayed = false;
	private int meepleLocation;
	private Meeple meeple;
	private int xLocation = 700;
	private int yLocation = 100;
	public static final int NUMDISTINCTTILES = 24;//number of visually distinct tiles
	public static final int NUMTILES = 72; //number of actual tiles, including repeats
	
	
	public Tile(String[] imageString){
		this.imageString = imageString;
	}

	public static void initTiles(Queue<Tile> tiles) {	//read in the tiles, then randomize their order
		
		int[] numInstances = {1,4,2,1,3,1,1,2,3,2,1,2,2,3,2,3,5,3,3,3,3,8,9,4,1};//number of instances of each tile according to the rules
		String [] firstTile = {"Tiles/0tile00.jpg", "Tiles/90tile00.jpg", "Tiles/180tile00.jpg", "Tiles/270tile00.jpg"};
		
		for (int i = 1; i <= NUMDISTINCTTILES; i++) {
			String[] baseString = {"Tiles/0tile", "Tiles/90tile", "Tiles/180tile","Tiles/270tile"}; 
			for(int j = 0; j<4;j++){
				baseString[j] += i + ".jpg";
			}
			for(int k = 0; k < numInstances[i]; k++){
				tiles.enqueue(new Tile(baseString));
			}
		}
		
		Tile[] shuffleTiles = new Tile[NUMTILES-1];
		for (int i = 0; i < shuffleTiles.length; i++) {
			shuffleTiles[i] = tiles.dequeue();
		}
		shuffleArray(shuffleTiles);
		tiles.enqueue(new Tile(firstTile));//put the first tile in the first spot in the queue.
		for (int i = 0; i < shuffleTiles.length; i++) {
			tiles.enqueue(shuffleTiles[i]);
		}
	}
	
	// Implementing Fisher–Yates shuffle
	static void shuffleArray(Tile[] ar) {
		Random rnd = new Random();
	    for (int i = ar.length - 1; i > 0; i--){
	    	int index = rnd.nextInt(i + 1);
	    	// Simple swap
	    	Tile a = ar[index];
	    	ar[index] = ar[i];
	    	ar[i] = a;
	    }
	}

	public boolean hasMeeple() {
		return hasMeeple;
	}

	public void setHasMeeple(boolean hasMeeple) {
		this.hasMeeple = hasMeeple;
	}

	public int getMeepleLocation() {
		return meepleLocation;
	}
	
	public void setBeenPlayed(Boolean b){
		this.beenPlayed = b;
	}

	public void setMeepleLocation(int meepleLocation) {
		this.meepleLocation = meepleLocation;
	}

	public Meeple getMeeple() {
		return meeple;
	}

	public void setMeeple(Meeple meeple) {
		this.meeple = meeple;
	}

	public String[] getImageFile() {
		return imageString;
	}

	public int getxLocation() {
		return xLocation;
	}

	public void setxLocation(int xLocation) {
		this.xLocation = xLocation;
	}
	
	public void setLocation(int xLocation, int yLocation){
		this.xLocation = xLocation;
		this.yLocation = yLocation;
	}

	public int getyLocation() {
		return yLocation;
	}

	public void setyLocation(int yLocation) {
		this.yLocation = yLocation;
	}

}
