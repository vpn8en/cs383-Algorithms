package carcassonne;

import java.util.Random;
import java.util.Scanner;

import edu.princeton.cs.algs4.Queue;

public class Player {

	public Meeple[] meeples = new Meeple[7];
	public String name;
	public String color;
	public int score = 0;

	public Player(String name, String color) {
		this.name = name;
		this.color = color;
		for (int i = 0; i < meeples.length; i++) {
			meeples[i] = new Meeple(color);
		}
	}

	static Queue<Player> createPlayers(int numPlayers, int MAX_PLAYERS) {// find players names, and create them
		
		Queue<Player> playerQueue = new Queue<Player>();
		Scanner s = new Scanner(System.in);
		while ((numPlayers == 0) || (numPlayers > MAX_PLAYERS) || (numPlayers ==1)) {
			System.out
					.println("Welcome to Carcassonne! Please enter the number of players. (Must be less than 5 and greater than 1).");
			numPlayers = Integer.parseInt(s.nextLine());
		}
		String[] color = { "Yellow", "Green", "Blue", "Red", "Black" };
		String name;
		for (int i = 0; i < numPlayers; i++) {
			System.out.println("Please Enter Player" + i + "'s Name.");
			name = s.nextLine().trim();
			System.out
					.println("Hi " + name + "! Your Color is " + color[i] + ".");
			Player player = new Player(name, color[i]);
			playerQueue.enqueue(player);
		}
		
		Player[] shufflePlayers = new Player[numPlayers];
		for (int i = 0; i< shufflePlayers.length; i++) {
			shufflePlayers[i] = playerQueue.dequeue();
		}
		shuffleArray(shufflePlayers);
		System.out.println("Here is the randomized order of the players!");
		for (int i = 0; i< shufflePlayers.length; i++) {
			playerQueue.enqueue(shufflePlayers[i]);
			System.out.println((i+1)+"."+shufflePlayers[i].name );
		}
		
		return playerQueue;
	}

	// Implementing Fisher–Yates shuffle
	static void shuffleArray(Player[] ar) {
		Random rnd = new Random();
		for (int i = ar.length - 1; i > 0; i--){
			int index = rnd.nextInt(i + 1);
			// Simple swap
			Player a = ar[index];
			ar[index] = ar[i];
			ar[i] = a;
		}
	}
	
	public int getNextFollower() {
		for(int i = 0; i < this.meeples.length; i++){
			if (!this.meeples[i].getOnBoard()){
				meeples[i].setOnBoard(true);
				return i;
			}
		}
		return -1;
	}
	
	public int getScore(){
		return this.score;
	}
	
	public void setScore(int s){
		this.score = score;
	}

	public Meeple[] getMeeples() {
		return meeples;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
