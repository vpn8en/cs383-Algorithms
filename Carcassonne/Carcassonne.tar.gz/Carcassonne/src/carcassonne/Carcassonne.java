package carcassonne;

import edu.princeton.cs.algs4.*;

public class Carcassonne {

	public static Queue<Tile> tiles;
	public static Queue<Player> playerQueue;
	public static int numPlayers = 0;
	public static final int MAX_PLAYERS = 5; 
	
	public Carcassonne() {
		tiles = new <Tile>Queue();
	}
	public static void main(String[] args) {
		new Carcassonne();
		playerQueue = Player.createPlayers(numPlayers, MAX_PLAYERS);
		Tile.initTiles(tiles);
		new CarcassonneGUI(playerQueue,tiles);
//		startGame();
	}
}
