package carcassonne;

public class Board {

}
